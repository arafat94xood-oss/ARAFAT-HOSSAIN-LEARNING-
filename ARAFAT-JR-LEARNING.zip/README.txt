ARAFAT JR LEARNING
===================

ব্যবহার:
1. ZIP ফাইলটি Extract করুন।
2. GitHub repository-তে index.html আপলোড করুন।
3. Commit changes চাপুন।
4. ওয়েবসাইট চালু করতে Repository Settings > Pages > Deploy from a branch > main > /(root) > Save নির্বাচন করুন।

গুরুত্বপূর্ণ:
- এটি বিনামূল্যের static demo website।
- নোট, সদস্য, MCQ ও আড্ডার বার্তা একই ব্রাউজারের localStorage-এ থাকে; অন্য ফোনে নিজে থেকে sync হয় না।
- লাইভ chat, নিরাপদ account/login, online database এবং বাস্তব PDF hosting এই প্যাকেজে নেই।
- Admin demo password: 1234। এটি নিরাপদ authentication নয়; প্রকাশ্য ব্যবহারের আগে backend ও secure login যোগ করতে হবে।
